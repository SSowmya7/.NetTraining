﻿namespace LINQPractice.Models
{
    public class DepartmentWiseEmployeeCount
    {
        public int DepartmentId {  get; set; }
        public int EmployeeCount { get; set; }
    }
}
