﻿namespace LINQPractice.Models
{
    public class EmployeeDepartmentDto
    {
        public string EmployeeName {  get; set; }
        public string DepartmentName { get; set; }
    }
}
