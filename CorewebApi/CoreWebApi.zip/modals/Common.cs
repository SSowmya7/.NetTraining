﻿namespace coremvc1.Models
{
    public class Common
    {
        public List<Employee> EmployeesList;



        public List<Course> CourseList;


    }
}
